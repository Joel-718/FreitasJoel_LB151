/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.mycompany.wordguesser;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;

/**
 *
 * @author joel_
 */
@ManagedBean
@SessionScoped
public class HighscoreBean implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String name;
    private int coins;    
   

    private List<Score> scores = new ArrayList<>();

    public List<Score> getScores() {
        // Holen Sie die Namen und Münzen aus der Session
        String name = (String) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("name");
        int coins = (int) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("coins");

        // Fügen Sie den neuen Score zur Liste hinzu
        Score score = new Score(name, coins);
        List<Score> scores = new ArrayList<>();
        scores.add(score);

        return scores;
    }

    public void addScore(String name, int coins) {
        scores.add(new Score(name, coins));
        Collections.sort(scores);
        if (scores.size() > 10) {
            scores.remove(scores.size() - 1);
        }
    }

    public class Score implements Comparable<Score>, Serializable {

        private static final long serialVersionUID = 1L;

        private String name;
        private int coins;

        public Score(String name, int coins) {
            this.name = name;
            this.coins = coins;
        }

        public String getName() {
            return name;
        }

        public int getCoins() {
            return coins;
        }

        @Override
        public int compareTo(Score o) {
            return Integer.compare(o.coins, coins);
        }
    }
}

