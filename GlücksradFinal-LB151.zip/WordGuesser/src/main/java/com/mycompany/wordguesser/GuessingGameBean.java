/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.mycompany.wordguesser;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;

@ManagedBean
@SessionScoped
public class GuessingGameBean implements Serializable {
    private static final long serialVersionUID = 1L;

    private String[] words = {"Hund", "Katze", "Maus"};
private String word;
private List<Character> correctGuesses;
private List<Character> wrongGuesses;
private int lives = 3;
private int coins;
private String guess;
private boolean gameEnded = false;
private boolean gameWon = false;
private String name;


public GuessingGameBean() {
    newGame();
    Random rand = new Random();
    word = words[rand.nextInt(words.length)];
}

public void checkGuess() {
    if (guess == null || guess.isEmpty()) {
        return;
    }
    if (guess.length() == 1) {
        char guessChar = guess.toUpperCase().charAt(0);
        if (word.toUpperCase().indexOf(guessChar) >= 0) {
            if (!correctGuesses.contains(guessChar)) {
                correctGuesses.set(word.toUpperCase().indexOf(guessChar), guessChar);
                coins += 50;
                // Münzen erhöhen, wenn die Vermutung korrekt ist
            }
            if (!correctGuesses.contains('_')) {
                // Das Spiel wird gewonnen, wenn kein Unterstrich mehr im Wort ist
                gameEnded = true;
                gameWon = true;
                coins += 500;
            }
        } else {
            if (lives > 0 && !wrongGuesses.contains(guessChar)) {
                wrongGuesses.add(guessChar);
                lives--;
            }
        }
    } else {
        if (guess.toUpperCase().equals(word.toUpperCase())) {
            // Das Spiel wird gewonnen, wenn das Wort richtig geraten wird
            gameEnded = true;
            gameWon = true;
            coins += 500;
        } else {
            if (lives > 0) {
                lives--;
            } else {
                // Spiel beendet
                gameEnded = true;
                gameWon = false;
                Random rand = new Random();
                word = words[rand.nextInt(words.length)];
                correctGuesses.clear();
                wrongGuesses.clear();
                lives = 3;
                coins = 0;
                for (int i = 0; i < word.length(); i++) {
                    correctGuesses.add('_');
                }
                newGame();
                return;
            }
        }
    }
    guess = "";
    checkEndGame();
}

public void revealLetter(char letter) {
    if (coins >= 100 && !gameEnded && word.indexOf(letter) != -1) {
        coins -= 100;
        for (int i = 0; i < word.length(); i++) {
            if (word.charAt(i) == letter) {
                correctGuesses.set(i, letter);
            }
        }
        if (!correctGuesses.contains('_')) {
            gameEnded = true;
            gameWon = true;
            coins += 500;
        }
    }
}

public void buyLetter(char letter) {
    if (coins >= 100) {
        coins -= 100;
        if (word.toUpperCase().indexOf(letter) >= 0) {
            // Der gekaufte Buchstabe kommt im Wort vor
            for (int i = 0; i < word.length(); i++) {
                if (word.toUpperCase().charAt(i) == letter) {
                    correctGuesses.set(i, letter);
                }
            }
        }
    }
    checkEndGame();
}

public String getPlayerName() {
    FacesContext context = FacesContext.getCurrentInstance();
    NameBean nameBean = (NameBean) context.getApplication().evaluateExpressionGet(context, "#{nameBean}", NameBean.class);
    return nameBean.getName();
}

public String getDisplayWord() {
StringBuilder displayWord = new StringBuilder();
for (char c : word.toCharArray()) {
if (correctGuesses.contains(Character.toUpperCase(c))) {
displayWord.append(c);
} else {
displayWord.append("_ ");
}
}
return displayWord.toString();
}

public String getGuess() {
    return guess;
}

public void setGuess(String guess) {
    this.guess = guess;
}

public int getLives() {
    return lives;
}

public void setLives(int lives) {
    this.lives = lives;
}

public int getCoins() {
    return coins;
}

public void setCoins(int coins) {
    this.coins = coins;
}

public void checkEndGame() {
    if (lives <= 0) {
        gameEnded = true;
        gameWon = false;
        Random rand = new Random();
        word = words[rand.nextInt(words.length)];
        correctGuesses.clear();
        wrongGuesses.clear();
        for (int i = 0; i < word.length(); i++) {
            correctGuesses.add('_');
        }
        newGame();
    } else if (!correctGuesses.contains('_')) {
        gameEnded = true;
        gameWon = true;
        coins += 500;
    }
}

public boolean isGameEnded() {
    return gameEnded;
}

public boolean isGameWon() {
    return gameWon;
}

public void continueGame() {
    if (!gameEnded) {
        return;
    }
    Random rand = new Random();
    word = words[rand.nextInt(words.length)];
    correctGuesses.clear();
    wrongGuesses.clear();
    for (int i = 0; i < word.length(); i++) {
        if (correctGuesses.size() < i+1) {
            correctGuesses.add('_');
        } else {
            correctGuesses.set(i, '_');
        }
    }
    guess = "";
    gameEnded = false;
    gameWon = false;
    checkEndGame();
}
    
    public void newGame() {
    Random rand = new Random();
    word = words[rand.nextInt(words.length)];
    correctGuesses = new ArrayList<>();
    wrongGuesses = new ArrayList<>();
    for (int i = 0; i < word.length(); i++) {
        correctGuesses.add('_');
    }
    gameEnded = false;
    gameWon = false;
}
    
    public boolean isGameOver() {
    return lives <= 0;
    }
}
