/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.mycompany.gluecksrad.lb151;

import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import java.io.Serializable;
import javax.faces.bean.ManagedBean;

/**
 *
 * @author joel_
 */
@ManagedBean(name="startseiteBean")
@SessionScoped
public class startseiteBean implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String spielerName;
    
    public String getSpielerName() {
        return spielerName;
    }
    
    public void setSpielerName(String name) {
        spielerName = name;
    }
}
