/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package com.mycompany.gluecksrad.lb151;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@ManagedBean(name="game")
@SessionScoped

public class Game implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String wordToGuess;
    private int lives;
    private int coins;
    private List<Character> guessedLetters;
    private char[] wordToGuessArray;
    private char[] guessedLettersArray;
    private String inputLetter;
    private String inputWord;
    private boolean gameOver;

    public Game() {
        startNewGame();
    }

    public void startNewGame() {
        String[] wordsToGuess = {"Hund", "Katze", "Affe", "Giraffe", "Elefant"};
        Random rand = new Random();
        wordToGuess = wordsToGuess[rand.nextInt(wordsToGuess.length)];
        lives = 3;
        coins = 0;
        guessedLetters = new ArrayList<Character>();
        wordToGuessArray = wordToGuess.toCharArray();
        guessedLettersArray = new char[wordToGuessArray.length];
        for (int i = 0; i < guessedLettersArray.length; i++) {
            guessedLettersArray[i] = '_';
        }
        inputLetter = "";
        inputWord = "";
        gameOver = false;
    }
    public void guessLetter() {
    if (gameOver) {
        return;
    }
    if (inputLetter == null || inputLetter.length() != 1) {
        return;
    }
    char letter = inputLetter.charAt(0);
    if (guessedLetters.contains(letter)) {
        return;
    }
    boolean letterFound = false;
    for (int i = 0; i < guessedLettersArray.length; i++) {
        if (wordToGuessArray[i] == letter) {
            guessedLettersArray[i] = letter;
            letterFound = true;
        }
    }
    guessedLetters.add(letter);
    if (letterFound) {
        coins += 50;
    } else {
        lives--;
    }
    if (lives == 0) {
        gameOver = true;
    }
    boolean wordGuessed = true;
    for (char c : guessedLettersArray) {
        if (c == '_') {
            wordGuessed = false;
            break;
        }
    }
    if (wordGuessed) {
        coins += 200;
        gameOver = true;
    }
    inputLetter = "";
}
}